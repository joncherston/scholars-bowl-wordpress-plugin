<?php
/**
 * Plugin Name: College Bowl Payment
 * Description: Standalone payment form for College Bowl tournament registration
 * Version: 1.0.4
 * Author: SUSCC
 */

if (!defined('ABSPATH')) exit;

define('CBP_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('CBP_PLUGIN_URL', plugin_dir_url(__FILE__));

class College_Bowl_Payment {
    private $table_name;
    
    public function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'college_bowl_payments';
        
        add_action('init', array($this, 'init'));
        register_activation_hook(__FILE__, array($this, 'activate'));
        
        // Prevent main plugin's scripts from loading on our page
        add_action('wp_enqueue_scripts', array($this, 'dequeue_conflicting_scripts'), 100);
    }
    
    public function dequeue_conflicting_scripts() {
        global $post;
        if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'college_bowl_payment')) {
            // Dequeue the main plugin's frontend script to avoid conflicts
            wp_dequeue_script('sbr-frontend');
            wp_deregister_script('sbr-frontend');
        }
    }
    
    public function activate() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE IF NOT EXISTS {$this->table_name} (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            name varchar(255) NOT NULL,
            email varchar(255) NOT NULL,
            college_name varchar(255) NOT NULL,
            num_teams int(11) NOT NULL,
            amount decimal(10,2) NOT NULL,
            stripe_payment_intent_id varchar(255) NOT NULL,
            payment_date datetime NOT NULL,
            ip_address varchar(45),
            transaction_details text,
            PRIMARY KEY  (id)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
    
    public function init() {
        add_shortcode('college_bowl_payment', array($this, 'payment_form_shortcode'));
        add_action('wp_ajax_cbp_process_payment', array($this, 'process_payment'));
        add_action('wp_ajax_nopriv_cbp_process_payment', array($this, 'process_payment'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
    }
    
    public function enqueue_scripts() {
        global $post;
        if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'college_bowl_payment')) {
            // Enqueue Stripe.js
            wp_enqueue_script('stripe-js', 'https://js.stripe.com/v3/', array(), null, false);
            
            wp_enqueue_style('cbp-styles', CBP_PLUGIN_URL . 'assets/style.css', array(), '1.0.2');
            wp_enqueue_script('cbp-script', CBP_PLUGIN_URL . 'assets/script.js', array('jquery'), '1.0.2', true);
            
            wp_localize_script('cbp-script', 'cbpData', array(
                'ajax_url' => admin_url('admin-ajax.php'),
                'publishable_key' => $this->get_publishable_key(),
                'pricing' => array(
                    '0' => 1.00,
                    '1' => floatval(get_option('cbp_one_team_price', 150)),
                    '2' => floatval(get_option('cbp_two_team_price', 200))
                )
            ));
        }
    }
    
    private function get_publishable_key() {
        $stripe_mode = get_option('sbr_stripe_mode', 'test');
        return ($stripe_mode === 'live') 
            ? get_option('sbr_stripe_live_publishable_key', '') 
            : get_option('sbr_stripe_test_publishable_key', '');
    }
    
    public function payment_form_shortcode($atts) {
        ob_start();
        
        // Check if showing confirmation
        if (isset($_GET['cbp_success']) && $_GET['cbp_success'] === '1' && isset($_GET['payment_id'])) {
            $this->show_confirmation(intval($_GET['payment_id']));
            return ob_get_clean();
        }
        
        $publishable_key = $this->get_publishable_key();
        if (empty($publishable_key)) {
            echo '<div class="cbp-error">Payment system is not configured.</div>';
            return ob_get_clean();
        }
        
        ?>
        <div id="college-bowl-payment-form">
            <h2><?php echo esc_html(get_option('cbp_event_name', 'College Bowl Tournament')); ?> Payment</h2>
            <p>Please complete the form below to pay for your College Bowl team registration.</p>
            
            <form id="cbp-payment-form" method="POST">
                <?php wp_nonce_field('cbp_payment', 'cbp_nonce'); ?>
                
                <div class="cbp-form-group">
                    <label for="cbp_name">Full Name *</label>
                    <input type="text" id="cbp_name" name="name" required>
                </div>
                
                <div class="cbp-form-group">
                    <label for="cbp_email">Email Address *</label>
                    <input type="email" id="cbp_email" name="email" required>
                </div>
                
                <div class="cbp-form-group">
                    <label for="cbp_college">College Name *</label>
                    <input type="text" id="cbp_college" name="college_name" required>
                </div>
                
                <div class="cbp-form-group">
                    <label for="cbp_teams">Number of Teams *</label>
                    <select id="cbp_teams" name="num_teams" required>
                        <option value="">Select number of teams</option>
                        <option value="1">1 Team - $<?php echo number_format(get_option('cbp_one_team_price', 150), 2); ?></option>
                        <option value="2">2 Teams - $<?php echo number_format(get_option('cbp_two_team_price', 200), 2); ?></option>
                        <?php if (get_option('cbp_enable_test_mode', '0') === '1'): ?>
                        <option value="0">Test - $1.00</option>
                        <?php endif; ?>
                    </select>
                </div>
                
                <div class="cbp-total-display" id="cbp_total_display" style="display: none;">
                    <h3>Total Amount: <span id="cbp_amount">$0.00</span></h3>
                </div>
                
                <div class="cbp-form-group">
                    <label>Credit Card Information</label>
                    <div id="card-element" class="cbp-card-element"></div>
                    <div id="card-errors" role="alert" class="cbp-error"></div>
                </div>
                
                <div class="cbp-form-actions">
                    <button type="submit" id="cbp_submit_btn" class="cbp-submit-btn">
                        Process Payment
                    </button>
                </div>
                
                <div id="cbp_processing" class="cbp-processing" style="display: none;">
                    <p>Processing your payment... Please wait.</p>
                </div>
            </form>
        </div>
        <?php
        
        return ob_get_clean();
    }
    
    public function process_payment() {
        check_ajax_referer('cbp_payment', 'nonce');
        
        global $wpdb;
        
        $name = sanitize_text_field($_POST['name']);
        $email = sanitize_email($_POST['email']);
        $college_name = sanitize_text_field($_POST['college_name']);
        $num_teams = intval($_POST['num_teams']);
        $payment_method_id = sanitize_text_field($_POST['payment_method_id']);
        
        if ($num_teams === 0) {
            $amount = 1.00;
        } elseif ($num_teams === 1) {
            $amount = floatval(get_option('cbp_one_team_price', 150));
        } else {
            $amount = floatval(get_option('cbp_two_team_price', 200));
        }
        
        if (empty($name) || empty($email) || !in_array($num_teams, [0, 1, 2])) {
            wp_send_json_error('Invalid form data');
        }
        
        $stripe_mode = get_option('sbr_stripe_mode', 'test');
        $secret_key = ($stripe_mode === 'live') 
            ? get_option('sbr_stripe_live_secret_key', '') 
            : get_option('sbr_stripe_test_secret_key', '');
            
        if (empty($secret_key)) {
            wp_send_json_error('Payment system not configured');
        }
        
        // --- LIBRARY FIX ---
        if (!class_exists('\Stripe\Stripe')) {
            $possible_paths = array(
                WP_PLUGIN_DIR . '/scholars-bowl-registration/lib/stripe-php/init.php',
                WP_PLUGIN_DIR . '/scholars-bowl-registration/vendor/autoload.php',
                WP_PLUGIN_DIR . '/scholars-bowl-registration-main/lib/stripe-php/init.php',
            );

            $library_found = false;
            foreach ($possible_paths as $path) {
                if (file_exists($path)) {
                    require_once $path;
                    $library_found = true;
                    break;
                }
            }
        }
        
        try {
            if (class_exists('\Stripe\Stripe')) {
                \Stripe\Stripe::setApiKey($secret_key);
            } else {
                 wp_send_json_error('Stripe class could not be loaded.');
            }
            
            $payment_intent = \Stripe\PaymentIntent::create([
                'amount' => intval($amount * 100),
                'currency' => 'usd',
                'payment_method' => $payment_method_id,
                'confirm' => true,
                'return_url' => add_query_arg('cbp_success', '1', $_POST['page_url']),
                'description' => "College Bowl - {$college_name} - {$num_teams} team(s)",
                'receipt_email' => $email,
                'metadata' => [
                    'name' => $name,
                    'college' => $college_name,
                    'teams' => $num_teams
                ]
            ]);
            
            if ($payment_intent->status === 'succeeded') {
                $wpdb->insert(
                    $this->table_name,
                    array(
                        'name' => $name,
                        'email' => $email,
                        'college_name' => $college_name,
                        'num_teams' => $num_teams,
                        'amount' => $amount,
                        'stripe_payment_intent_id' => $payment_intent->id,
                        'payment_date' => current_time('mysql'),
                        'ip_address' => $_SERVER['REMOTE_ADDR'],
                        'transaction_details' => json_encode(['payment_method' => $payment_method_id])
                    ),
                    array('%s', '%s', '%s', '%d', '%f', '%s', '%s', '%s', '%s')
                );
                
                if ($wpdb->insert_id) {
                    $this->send_confirmation_email($wpdb->insert_id);
                    $this->send_notification_email($wpdb->insert_id);
                    
                    wp_send_json_success(array(
                        'redirect_url' => add_query_arg([
                            'cbp_success' => '1',
                            'payment_id' => $wpdb->insert_id
                        ], !empty($_POST['page_url']) ? esc_url_raw($_POST['page_url']) : home_url())
                    ));
                }
            } elseif ($payment_intent->status === 'requires_action') {
                wp_send_json_success(array(
                    'requires_action' => true,
                    'client_secret' => $payment_intent->client_secret,
                    'return_url' => add_query_arg('cbp_success', '1', $_POST['page_url'])
                ));
            }
            
            wp_send_json_error('Payment failed');
            
        } catch (\Stripe\Exception\CardException $e) {
            wp_send_json_error($e->getMessage());
        } catch (Exception $e) {
            wp_send_json_error('Payment error: ' . $e->getMessage());
        }
    }
    
    private function send_confirmation_email($payment_id) {
        global $wpdb;
        
        $payment = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$this->table_name} WHERE id = %d",
            $payment_id
        ));
        
        if (!$payment) return false;
        
        $to = $payment->email;
        $subject = 'College Bowl Payment Confirmation';
        
        $message = "Dear {$payment->name},\n\n";
        $message .= "We have received your payment for the College Bowl Tournament.\n\n";
        $message .= "Payment Details:\n";
        $message .= "Name: {$payment->name}\n";
        $message .= "College: {$payment->college_name}\n";
        $message .= "Teams: " . ($payment->num_teams == 0 ? "TEST" : $payment->num_teams) . "\n";
        $message .= "Amount: $" . number_format($payment->amount, 2) . "\n";
        $message .= "Transaction ID: {$payment->stripe_payment_intent_id}\n\n";
        $message .= "Thank you!\n";
        
        $headers = array('Content-Type: text/plain; charset=UTF-8');
        
        return wp_mail($to, $subject, $message, $headers);
    }

    // --- UPDATED NOTIFICATION FUNCTION ---
    private function send_notification_email($payment_id) {
        global $wpdb;
        
        $payment = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$this->table_name} WHERE id = %d",
            $payment_id
        ));
        
        if (!$payment) return false;

        // 1. Get the raw value from the database using the ID you found: cbp_billing_contact
        $raw_contact = get_option('cbp_billing_contact', '');
        
        // 2. Extract the email address (ignores the name)
        if (empty($raw_contact)) {
            $to = get_option('admin_email');
        } else {
            // This Regex finds the first valid email address in the text
            if (preg_match('/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/', $raw_contact, $matches)) {
                $to = $matches[0];
            } else {
                // Fallback to admin if no email pattern found
                $to = get_option('admin_email');
            }
        }

        $subject = 'New College Bowl Payment Received';
        
        $message = "A new payment has been received for the College Bowl Tournament.\n\n";
        $message .= "College: {$payment->college_name}\n";
        $message .= "Payer: {$payment->name} ({$payment->email})\n";
        $message .= "Amount: $" . number_format($payment->amount, 2) . "\n";
        $message .= "Teams: " . ($payment->num_teams == 0 ? "TEST" : $payment->num_teams) . "\n\n";
        $message .= "Payment ID: {$payment->stripe_payment_intent_id}\n";
        
        $headers = array('Content-Type: text/plain; charset=UTF-8');
        
        return wp_mail($to, $subject, $message, $headers);
    }
    
    private function show_confirmation($payment_id) {
        global $wpdb;
        
        $payment = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$this->table_name} WHERE id = %d",
            $payment_id
        ));
        
        if (!$payment) {
            echo '<div class="cbp-error">Payment not found.</div>';
            return;
        }
        
        ?>
        <div class="cbp-confirmation">
            <h2>✅ Payment Confirmed!</h2>
            <p>Thank you for your payment. A confirmation email has been sent to <strong><?php echo esc_html($payment->email); ?></strong>.</p>
            
            <div class="cbp-receipt">
                <h3>Payment Receipt</h3>
                <table>
                    <tr><td><strong>Name:</strong></td><td><?php echo esc_html($payment->name); ?></td></tr>
                    <tr><td><strong>College:</strong></td><td><?php echo esc_html($payment->college_name); ?></td></tr>
                    <tr><td><strong>Teams:</strong></td><td><?php echo ($payment->num_teams == 0) ? 'TEST' : $payment->num_teams; ?></td></tr>
                    <tr><td><strong>Amount:</strong></td><td>$<?php echo number_format($payment->amount, 2); ?></td></tr>
                    <tr><td><strong>Transaction ID:</strong></td><td><?php echo esc_html($payment->stripe_payment_intent_id); ?></td></tr>
                    <tr><td><strong>Date:</strong></td><td><?php echo date('F j, Y g:i A', strtotime($payment->payment_date)); ?></td></tr>
                </table>
            </div>
        </div>
        <?php
    }
}

new College_Bowl_Payment();