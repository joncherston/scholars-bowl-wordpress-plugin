(function() {
    'use strict';
    
    // Wait for DOM and Stripe to be ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initPaymentForm);
    } else {
        initPaymentForm();
    }
    
    function initPaymentForm() {
        console.log('CBP: Initializing payment form');
        
        // Check if Stripe is loaded
        if (typeof Stripe === 'undefined') {
            console.error('CBP: Stripe not loaded');
            return;
        }
        
        // Get elements
        var form = document.getElementById('cbp-payment-form');
        var teamsSelect = document.getElementById('cbp_teams');
        var cardElement = document.getElementById('card-element');
        
        if (!form || !teamsSelect || !cardElement) {
            console.log('CBP: Form elements not found on this page');
            return;
        }
        
        console.log('CBP: Form elements found, initializing Stripe');
        
        // Initialize Stripe
        var stripe = Stripe(cbpData.publishable_key);
        var elements = stripe.elements();
        var card = elements.create('card', {
            style: {
                base: {
                    fontSize: '16px',
                    color: '#32325d',
                    fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
                    '::placeholder': {
                        color: '#aab7c4'
                    }
                },
                invalid: {
                    color: '#fa755a',
                    iconColor: '#fa755a'
                }
            }
        });
        
        card.mount('#card-element');
        console.log('CBP: Card element mounted');
        
        // Handle card errors
        card.on('change', function(event) {
            var displayError = document.getElementById('card-errors');
            if (event.error) {
                displayError.textContent = event.error.message;
            } else {
                displayError.textContent = '';
            }
        });
        
        // Handle team selection change
        teamsSelect.addEventListener('change', function() {
            var teams = parseInt(this.value);
            var amount = cbpData.pricing[teams] || 0;
            
            if (amount > 0) {
                document.getElementById('cbp_amount').textContent = '$' + amount.toFixed(2);
                document.getElementById('cbp_total_display').style.display = 'block';
            } else {
                document.getElementById('cbp_total_display').style.display = 'none';
            }
        });
        
        // Handle form submission
        form.addEventListener('submit', function(event) {
            event.preventDefault();
            console.log('CBP: Form submitted');
            
            var teams = teamsSelect.value;
            if (!teams) {
                alert('Please select number of teams');
                return;
            }
            
            var submitBtn = document.getElementById('cbp_submit_btn');
            var processingDiv = document.getElementById('cbp_processing');
            
            submitBtn.disabled = true;
            submitBtn.textContent = 'Processing...';
            processingDiv.style.display = 'block';
            
            // Create payment method
            stripe.createPaymentMethod({
                type: 'card',
                card: card,
                billing_details: {
                    name: document.getElementById('cbp_name').value,
                    email: document.getElementById('cbp_email').value
                }
            }).then(function(result) {
                if (result.error) {
                    console.error('CBP: Stripe error:', result.error);
                    document.getElementById('card-errors').textContent = result.error.message;
                    submitBtn.disabled = false;
                    submitBtn.textContent = 'Process Payment';
                    processingDiv.style.display = 'none';
                } else {
                    console.log('CBP: Payment method created, processing payment');
                    processPayment(result.paymentMethod.id, stripe);
                }
            });
        });
        
        function processPayment(paymentMethodId, stripeInstance) {
            var formData = new FormData();
            formData.append('action', 'cbp_process_payment');
            formData.append('nonce', document.querySelector('[name="cbp_nonce"]').value);
            formData.append('payment_method_id', paymentMethodId);
            formData.append('name', document.getElementById('cbp_name').value);
            formData.append('email', document.getElementById('cbp_email').value);
            formData.append('college_name', document.getElementById('cbp_college').value);
            formData.append('num_teams', document.getElementById('cbp_teams').value);
            formData.append('page_url', window.location.href);
            
            fetch(cbpData.ajax_url, {
                method: 'POST',
                body: formData
            })
            .then(function(response) {
                return response.json();
            })
            .then(function(data) {
                console.log('CBP: Server response:', data);
                
                if (data.success) {
                    if (data.data.requires_action) {
                        // Handle 3D Secure
                        stripeInstance.confirmCardPayment(data.data.client_secret).then(function(result) {
                            if (result.error) {
                                alert('Payment failed: ' + result.error.message);
                                location.reload();
                            } else {
                                window.location.href = data.data.return_url + '&payment_id=' + result.paymentIntent.id;
                            }
                        });
                    } else {
                        // Payment succeeded
                        window.location.href = data.data.redirect_url;
                    }
                } else {
                    alert('Error: ' + (data.data || 'Unknown error'));
                    location.reload();
                }
            })
            .catch(function(error) {
                console.error('CBP: Fetch error:', error);
                alert('An error occurred. Please try again.');
                location.reload();
            });
        }
    }
})();
