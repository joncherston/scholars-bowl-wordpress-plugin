<?php
if (!defined('ABSPATH')) exit;

class SBR_College_Bowl_Payment {
    private $table_name;
    
    public function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'college_bowl_payments';
        add_action('init', array($this, 'init'));
    }
    
    public function init() {
        add_shortcode('college_bowl_payment', array($this, 'payment_form_shortcode'));
        add_action('wp_ajax_cbp_process_payment', array($this, 'process_payment'));
        add_action('wp_ajax_nopriv_cbp_process_payment', array($this, 'process_payment'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
    }
    
    public function enqueue_scripts() {
        global $post;
        // Check if the current page/post has the shortcode
        if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'college_bowl_payment')) {
            wp_enqueue_script('stripe-js', 'https://js.stripe.com/v3/', array(), null, true);
            wp_enqueue_style('cbp-styles', SBR_PLUGIN_URL . 'assets/college-bowl.css', array(), SBR_VERSION);
        }
    }
    
    public function payment_form_shortcode($atts) {
        ob_start();
        
        // Check if we're showing confirmation
        if (isset($_GET['cbp_success']) && $_GET['cbp_success'] === '1' && isset($_GET['payment_id'])) {
            $this->show_confirmation(intval($_GET['payment_id']));
            return ob_get_clean();
        }
        
        // Get Stripe publishable key
        $stripe_mode = get_option('sbr_stripe_mode', 'test');
        $publishable_key = ($stripe_mode === 'live') 
            ? get_option('sbr_stripe_live_publishable_key', '') 
            : get_option('sbr_stripe_test_publishable_key', '');
            
        if (empty($publishable_key)) {
            echo '<div class="cbp-error">Payment system is not configured. Please contact the administrator.</div>';
            return ob_get_clean();
        }
        
        ?>
        <div id="college-bowl-payment-form">
            <h2><?php echo esc_html(get_option("cbp_event_name", "Upcoming College Bowl Tournament at Southern Union State Community College")); ?> Payment</h2>
            <p>Please complete the form below to pay for your College Bowl team registration.</p>
            
            <form id="cbp-payment-form" method="POST" action="" onsubmit="return false;">
                <?php wp_nonce_field('cbp_payment', 'cbp_nonce'); ?>
                
                <div class="cbp-form-group">
                    <label for="cbp_name">Full Name *</label>
                    <input type="text" id="cbp_name" name="name" required>
                </div>
                
                <div class="cbp-form-group">
                    <label for="cbp_email">Email Address *</label>
                    <input type="email" id="cbp_email" name="email" required>
                </div>
                
                <div class="cbp-form-group">
                    <label for="cbp_college">College Name *</label>
                    <input type="text" id="cbp_college" name="college_name" required>
                </div>
                
                <div class="cbp-form-group">
                    <label for="cbp_teams">Number of Teams *</label>
                    <select id="cbp_teams" name="num_teams" required>
                        <option value="">Select number of teams</option>
                        <option value="1">1 Team - $<?php echo number_format(get_option('cbp_one_team_price', 150), 2); ?></option>
                        <option value="2">2 Teams - $<?php echo number_format(get_option('cbp_two_team_price', 200), 2); ?></option>
                        <?php if (get_option('cbp_enable_test_mode', '0') === '1'): ?>
                        <option value="0">Test - $1.00 (Live test payment)</option>
                        <?php endif; ?>
                    </select>
                </div>
                
                <div class="cbp-total-display" id="cbp_total_display" style="display: none;">
                    <h3>Total Amount: <span id="cbp_amount">$0.00</span></h3>
                </div>
                
                <div class="cbp-form-group">
                    <label>Credit Card Information</label>
                    <div id="card-element" class="cbp-card-element"></div>
                    <div id="card-errors" role="alert" class="cbp-error"></div>
                </div>
                
                <div class="cbp-form-actions">
                    <button type="submit" id="cbp_submit_btn" class="cbp-submit-btn">
                        Process Payment
                    </button>
                </div>
                
                <div id="cbp_processing" class="cbp-processing" style="display: none;">
                    <p>Processing your payment... Please wait.</p>
                </div>
            </form>
        </div>
        
        <script>
        console.log('CBP: Script tag loaded');
        document.addEventListener('DOMContentLoaded', function() {
            console.log('CBP: DOMContentLoaded fired');
            if (typeof Stripe === 'undefined') {
                console.error('CBP ERROR: Stripe library not loaded');
                alert('Payment system error: Stripe library not loaded. Please refresh the page or contact support.');
                return;
            }
            console.log('CBP: Stripe library loaded successfully');
            
        var cbpStripe = Stripe('<?php echo esc_js($publishable_key); ?>');
        console.log('CBP: Stripe instance created');
        var cbpElements = cbpStripe.elements();
        var cbpCard = cbpElements.create('card', {
            style: {
                base: {
                    fontSize: '16px',
                    color: '#32325d',
                    fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
                    '::placeholder': {
                        color: '#aab7c4'
                    }
                },
                invalid: {
                    color: '#fa755a',
                    iconColor: '#fa755a'
                }
            }
        });
        cbpCard.mount('#card-element');
        
        cbpCard.on('change', function(event) {
            var displayError = document.getElementById('card-errors');
            if (event.error) {
                displayError.textContent = event.error.message;
            } else {
                displayError.textContent = '';
            }
        });
        
        var cbpPricing = {
            0: 1.00,
            1: <?php echo floatval(get_option("cbp_one_team_price", 150)); ?>,
            2: <?php echo floatval(get_option("cbp_two_team_price", 200)); ?>
        };
        
        function cbpCalculateTotal() {
            var teams = parseInt(document.getElementById("cbp_teams").value);
            var amount = cbpPricing[teams] || 0;
            
            if (amount > 0) {
                document.getElementById('cbp_amount').textContent = '$' + amount.toFixed(2);
                document.getElementById('cbp_total_display').style.display = 'block';
            } else {
                document.getElementById('cbp_total_display').style.display = 'none';
            }
        }
        
        var form = document.getElementById('cbp-payment-form');
        var teamsSelect = document.getElementById('cbp_teams');
        
        // Add change event listener for team selection
        if (teamsSelect) {
            teamsSelect.addEventListener('change', cbpCalculateTotal);
            console.log('CBP: Attached change listener to teams select');
        }
        
        if (form) {
            console.log('CBP: Attaching submit event listener to form');
            form.addEventListener('submit', function(event) {
                console.log('CBP: Form submit event fired');
                event.preventDefault();
            
            var teams = document.getElementById('cbp_teams').value;
            if (!teams) {
                alert('Please select number of teams');
                return;
            }
            
            var submitBtn = document.getElementById('cbp_submit_btn');
            var processingDiv = document.getElementById('cbp_processing');
            
            submitBtn.disabled = true;
            submitBtn.textContent = 'Processing...';
            processingDiv.style.display = 'block';
            
            cbpStripe.createPaymentMethod({
                type: 'card',
                card: cbpCard,
                billing_details: {
                    name: document.getElementById('cbp_name').value,
                    email: document.getElementById('cbp_email').value
                }
            }).then(function(result) {
                if (result.error) {
                    document.getElementById('card-errors').textContent = result.error.message;
                    submitBtn.disabled = false;
                    submitBtn.textContent = 'Process Payment';
                    processingDiv.style.display = 'none';
                } else {
                    cbpProcessPayment(result.paymentMethod.id);
                }
            });
            }); // Close form.addEventListener
        } else {
            console.error('CBP ERROR: Form element not found');
        }
        
        function cbpProcessPayment(paymentMethodId) {
            var formData = new FormData();
            formData.append('action', 'cbp_process_payment');
            formData.append('nonce', document.querySelector('[name="cbp_nonce"]').value);
            formData.append('payment_method_id', paymentMethodId);
            formData.append('name', document.getElementById('cbp_name').value);
            formData.append('email', document.getElementById('cbp_email').value);
            formData.append('college_name', document.getElementById('cbp_college').value);
            formData.append('num_teams', document.getElementById('cbp_teams').value);
            formData.append("page_url", window.location.href);
            
            console.log('CBP: Sending AJAX request to process payment');
            fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                method: 'POST',
                body: formData
            })
            .then(response => {
                console.log('CBP: Got response, status:', response.status);
                return response.json();
            })
            .then(function(data) {
                console.log('CBP: Response data:', data);
                if (data.success) {
                    if (data.data.requires_action) {
                        cbpStripe.confirmCardPayment(data.data.client_secret).then(function(result) {
                            if (result.error) {
                                alert('Payment failed: ' + result.error.message);
                                location.reload();
                            } else {
                                window.location.href = data.data.redirect_url;
                            }
                        });
                    } else {
                        window.location.href = data.data.redirect_url;
                    }
                } else {
                    alert('Error: ' + data.data);
                    location.reload();
                }
            })
            .catch(function(error) {
                alert('An error occurred. Please try again.');
                location.reload();
            });
        }
        }); // End DOMContentLoaded
        </script>
        <?php
        
        return ob_get_clean();
    }
    
    public function process_payment() {
        error_log('CBP: process_payment called');
        check_ajax_referer('cbp_payment', 'nonce');
        error_log('CBP: Nonce verified');
        
        global $wpdb;
        
        // Get form data
        $name = sanitize_text_field($_POST['name']);
        $email = sanitize_email($_POST['email']);
        $college_name = sanitize_text_field($_POST['college_name']);
        $num_teams = intval($_POST['num_teams']);
        $payment_method_id = sanitize_text_field($_POST['payment_method_id']);
        
        // Calculate amount based on number of teams
        if ($num_teams === 0) {
            $amount = 1.00; // Test payment
        } elseif ($num_teams === 1) {
            $amount = floatval(get_option('cbp_one_team_price', 150));
        } else {
            $amount = floatval(get_option('cbp_two_team_price', 200));
        }
        
        // Validate
        if (empty($name) || empty($email) || !in_array($num_teams, [0, 1, 2])) {
            wp_send_json_error('Invalid form data');
        }
        
        // Get Stripe secret key
        $stripe_mode = get_option('sbr_stripe_mode', 'test');
        $secret_key = ($stripe_mode === 'live') 
            ? get_option('sbr_stripe_live_secret_key', '') 
            : get_option('sbr_stripe_test_secret_key', '');
            
        if (empty($secret_key)) {
            wp_send_json_error('Payment system not configured');
        }
        
        // Process with Stripe
        require_once SBR_PLUGIN_PATH . 'lib/stripe-php/init.php';
        error_log('CBP: About to call Stripe API with amount: ' . $amount);
        
        try {
            \Stripe\Stripe::setApiKey($secret_key);
            error_log('CBP: Stripe API key set');
            
            $payment_intent = \Stripe\PaymentIntent::create([
                'amount' => intval($amount * 100),
                'currency' => 'usd',
                'payment_method' => $payment_method_id,
                'confirm' => true,
                'description' => "College Bowl - {$college_name} - {$num_teams} team(s)",
                'receipt_email' => $email,
                'metadata' => [
                    'name' => $name,
                    'college' => $college_name,
                    'teams' => $num_teams
                ]
            ]);
            
            if ($payment_intent->status === 'succeeded') {
                // Save to database
                $payment_id = $wpdb->insert(
                    $this->table_name,
                    array(
                        'name' => $name,
                        'email' => $email,
                        'college_name' => $college_name,
                        'num_teams' => $num_teams,
                        'amount' => $amount,
                        'stripe_payment_intent_id' => $payment_intent->id,
                        'payment_date' => current_time('mysql'),
                        'ip_address' => $this->get_client_ip(),
                        'transaction_details' => json_encode([
                            'payment_method' => $payment_method_id,
                            'status' => $payment_intent->status
                        ])
                    ),
                    array('%s', '%s', '%s', '%d', '%f', '%s', '%s', '%s', '%s')
                );
                
                if ($payment_id) {
                    // Send confirmation email
                    $this->send_confirmation_email($wpdb->insert_id);
                    
                    // Send notification to billing contact
                    $this->send_admin_notification($wpdb->insert_id);
                    
                    wp_send_json_success(array(
                        'redirect_url' => add_query_arg([
                            'cbp_success' => '1',
                            'payment_id' => $wpdb->insert_id
                        ], !empty($_POST["page_url"]) ? esc_url_raw($_POST["page_url"]) : home_url())
                    ));
                } else {
                    wp_send_json_error('Payment processed but database error occurred. Please contact support.');
                }
            } elseif ($payment_intent->status === 'requires_action') {
                wp_send_json_success(array(
                    'requires_action' => true,
                    'client_secret' => $payment_intent->client_secret
                ));
            } else {
                wp_send_json_error('Payment failed. Please try again.');
            }
            
        } catch (\Stripe\Exception\CardException $e) {
            error_log('CBP: Stripe CardException: ' . $e->getMessage());
            wp_send_json_error($e->getMessage());
        } catch (Exception $e) {
            error_log('CBP: Exception: ' . $e->getMessage());
            wp_send_json_error('Payment processing error: ' . $e->getMessage());
        }
    }
    
    private function send_confirmation_email($payment_id) {
        global $wpdb;
        
        $payment = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$this->table_name} WHERE id = %d",
            $payment_id
        ));
        
        if (!$payment) return false;
        
        $to = $payment->email;
        $subject = 'College Bowl Tournament Payment Confirmation';
        
        $event_name = get_option("cbp_event_name", "Upcoming College Bowl Tournament at Southern Union State Community College");
        $event_info_contact = get_option("cbp_event_info_contact", "Brent Catchings bcatchings@suscc.edu");
        $billing_contact = get_option("cbp_billing_contact", "Jonathan Herston jherston@suscc.edu");
        $message = "Dear {$payment->name},\n\n";
        $message .= "We have successfully received your payment for the {$event_name}!\n\n";
        $message .= "Below are the details of your payment for any documentation needs you may have with your college. If you have any questions or issues, feel free to reach out to us.\n\n";
        $message .= "For event information contact {$event_info_contact}\n";
        $message .= "For billing and payment questions contact {$billing_contact}\n\n";
        $message .= "We look forward to seeing you soon!\n\n";
        $message .= "Sincerely,\n";
        $message .= "SUSCC Social Sciences Department\n\n";
        $message .= "----------------------------------------\n";
        $message .= "PAYMENT RECEIPT\n";
        $message .= "----------------------------------------\n\n";
        $message .= "Receipt Date: " . date('F j, Y', strtotime($payment->payment_date)) . "\n";
        $message .= "Name: {$payment->name}\n";
        $message .= "College: {$payment->college_name}\n";
        $message .= "Event: {$event_name}\n";
        $message .= "Number of Teams: " . (($payment->num_teams == 0) ? "TEST PAYMENT" : $payment->num_teams) . "\n";
        $message .= "Payment Method: Credit Card\n";
        $message .= "Amount Paid: $" . number_format($payment->amount, 2) . "\n";
        $message .= "Transaction ID: {$payment->stripe_payment_intent_id}\n\n";
        $message .= "This receipt confirms your payment has been processed successfully.\n";
        
        $headers = array(
            'Content-Type: text/plain; charset=UTF-8',
            'From: SUSCC Social Sciences <jherston@suscc.edu>'
        );
        
        return wp_mail($to, $subject, $message, $headers);
    }
    
    private function show_confirmation($payment_id) {
        global $wpdb;
        
        $payment = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$this->table_name} WHERE id = %d",
            $payment_id
        ));
        
        if (!$payment) {
            echo '<div class="cbp-error">Payment not found.</div>';
            return;
        }
        
        ?>
        <div class="cbp-confirmation">
            <h2>✓ Payment Successful!</h2>
            <p>Thank you for your payment. A confirmation email has been sent to <strong><?php echo esc_html($payment->email); ?></strong></p>
            
            <div class="cbp-receipt">
                <h3>Payment Receipt</h3>
                <table class="cbp-receipt-table">
                    <tr>
                        <td><strong>Receipt Date:</strong></td>
                        <td><?php echo date('F j, Y', strtotime($payment->payment_date)); ?></td>
                    </tr>
                    <tr>
                        <td><strong>Name:</strong></td>
                        <td><?php echo esc_html($payment->name); ?></td>
                    </tr>
                    <tr>
                        <td><strong>College:</strong></td>
                        <td><?php echo esc_html($payment->college_name); ?></td>
                    </tr>
                    <tr>
                        <td><strong>Event:</strong></td>
                        <td><?php echo esc_html(get_option("cbp_event_name", "Upcoming College Bowl Tournament at Southern Union State Community College")); ?></td>
                    </tr>
                    <tr>
                        <td><strong>Number of Teams:</strong></td>
                        <td><?php echo ($payment->num_teams == 0) ? '<strong style="color:#dc3232">TEST PAYMENT</strong>' : $payment->num_teams; ?></td>
                    </tr>
                    <tr>
                        <td><strong>Payment Method:</strong></td>
                        <td>Credit Card</td>
                    </tr>
                    <tr>
                        <td><strong>Amount Paid:</strong></td>
                        <td><strong>$<?php echo number_format($payment->amount, 2); ?></strong></td>
                    </tr>
                    <tr>
                        <td><strong>Transaction ID:</strong></td>
                        <td><code><?php echo esc_html($payment->stripe_payment_intent_id); ?></code></td>
                    </tr>
                </table>
                
                <p style="margin-top: 20px;">
                    <button onclick="window.print();" class="cbp-print-btn">Print Receipt</button>
                </p>
                
                <div class="cbp-contacts">
                    <p><strong>For event information contact:</strong><br>
                    Brent Catchings - bcatchings@suscc.edu</p>
                    
                    <p><strong>For billing and payment questions contact:</strong><br>
                    Jonathan Herston - jherston@suscc.edu</p>
                </div>
            </div>
        </div>
        <?php
    }
    
    private function send_admin_notification($payment_id) {
        global $wpdb;
        
        $payment = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$this->table_name} WHERE id = %d",
            $payment_id
        ));
        
        if (!$payment) return false;
        
        // Get billing contact email
        $billing_contact = get_option("cbp_billing_contact", "Jonathan Herston jherston@suscc.edu");
        
        // Extract email from contact string
        preg_match("/[\w\.-]+@[\w\.-]+\.[\w]+/", $billing_contact, $matches);
        $to = isset($matches[0]) ? $matches[0] : "jherston@suscc.edu";
        
        $subject = "New College Bowl Payment Received";
        
        $message = "A new payment has been received for the College Bowl Tournament.\n\n";
        $message .= "PAYMENT DETAILS\n";
        $message .= "----------------------------------------\n";
        $message .= "Date: " . date("F j, Y g:i A", strtotime($payment->payment_date)) . "\n";
        $message .= "Name: {$payment->name}\n";
        $message .= "Email: {$payment->email}\n";
        $message .= "College: {$payment->college_name}\n";
        $message .= "Number of Teams: " . (($payment->num_teams == 0) ? "TEST PAYMENT" : $payment->num_teams) . "\n";
        $message .= "Amount: $" . number_format($payment->amount, 2) . "\n";
        $message .= "Transaction ID: {$payment->stripe_payment_intent_id}\n\n";
        $message .= "View all payments: " . admin_url("admin.php?page=college-bowl-payments") . "\n";
        
        $headers = array(
            "Content-Type: text/plain; charset=UTF-8",
            "From: College Bowl Payments <noreply@suscholarsbowl.com>"
        );
        
        return wp_mail($to, $subject, $message, $headers);
    }
    

    private function get_client_ip() {
        $ip = '';
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } else {
            $ip = $_SERVER['REMOTE_ADDR'] ?? '';
        }
        return sanitize_text_field($ip);
    }
}

// Initialize
new SBR_College_Bowl_Payment();
