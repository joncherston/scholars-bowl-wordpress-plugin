<?php
if (!defined('ABSPATH')) exit;

// Settings page for College Bowl configuration
function college_bowl_settings_page() {
    if (isset($_POST['cbp_save_settings'])) {
        update_option('cbp_one_team_price', floatval($_POST['cbp_one_team_price']));
        update_option('cbp_two_team_price', floatval($_POST['cbp_two_team_price']));
        update_option('cbp_event_name', sanitize_text_field($_POST['cbp_event_name']));
        update_option('cbp_event_info_contact', sanitize_text_field($_POST['cbp_event_info_contact']));
        update_option('cbp_billing_contact', sanitize_text_field($_POST['cbp_billing_contact']));
        update_option('cbp_enable_test_mode', isset($_POST['cbp_enable_test_mode']) ? '1' : '0');
        echo '<div class="notice notice-success"><p>Settings saved successfully!</p></div>';
    }
    
    $one_team = get_option('cbp_one_team_price', 150);
    $two_team = get_option('cbp_two_team_price', 200);
    $event_name = get_option('cbp_event_name', 'Upcoming College Bowl Tournament at Southern Union State Community College');
    $event_info = get_option('cbp_event_info_contact', 'Brent Catchings bcatchings@suscc.edu');
    $billing = get_option('cbp_billing_contact', 'Jonathan Herston jherston@suscc.edu');
    $test_mode = get_option('cbp_enable_test_mode', '0');
    ?>
    <div class="wrap">
        <h1>College Bowl Payment Settings</h1>
        <form method="post">
            <?php wp_nonce_field('cbp_settings', 'cbp_settings_nonce'); ?>
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="cbp_one_team_price">Price for 1 Team</label></th>
                    <td>
                        <input type="number" step="0.01" id="cbp_one_team_price" name="cbp_one_team_price" 
                               value="<?php echo esc_attr($one_team); ?>" class="regular-text" required>
                        <p class="description">Price in USD for registering one team</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="cbp_two_team_price">Price for 2 Teams</label></th>
                    <td>
                        <input type="number" step="0.01" id="cbp_two_team_price" name="cbp_two_team_price" 
                               value="<?php echo esc_attr($two_team); ?>" class="regular-text" required>
                        <p class="description">Price in USD for registering two teams</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="cbp_event_name">Event Name</label></th>
                    <td>
                        <input type="text" id="cbp_event_name" name="cbp_event_name" 
                               value="<?php echo esc_attr($event_name); ?>" class="large-text" required>
                        <p class="description">Full name of the event for receipts</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="cbp_event_info_contact">Event Information Contact</label></th>
                    <td>
                        <input type="text" id="cbp_event_info_contact" name="cbp_event_info_contact" 
                               value="<?php echo esc_attr($event_info); ?>" class="large-text" required>
                        <p class="description">Contact for event questions (Name and email)</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="cbp_billing_contact">Billing/Payment Contact</label></th>
                    <td>
                        <input type="text" id="cbp_billing_contact" name="cbp_billing_contact" 
                               value="<?php echo esc_attr($billing); ?>" class="large-text" required>
                        <p class="description">Contact for billing questions (Name and email)</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="cbp_enable_test_mode">Live Test Mode</label></th>
                    <td>
                        <label>
                            <input type="checkbox" id="cbp_enable_test_mode" name="cbp_enable_test_mode" 
                                   value="1" <?php checked($test_mode, '1'); ?>>
                            Enable live test option (charges $1.00)
                        </label>
                        <p class="description">
                            When enabled, a "Test" option will appear in the payment form that charges $1.00 to test live payment processing. 
                            <strong>Disable this after testing to hide the test option from users.</strong>
                        </p>
                    </td>
                </tr>
            </table>
            <p class="submit">
                <input type="submit" name="cbp_save_settings" class="button button-primary" value="Save Settings">
            </p>
        </form>
        
        <hr>
        <h2>Shortcode</h2>
        <p>Use this shortcode to display the payment form on any page:</p>
        <p><code>[college_bowl_payment]</code></p>
    </div>
    <?php
}

// Payments listing page
function college_bowl_admin_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'college_bowl_payments';
    
    if (isset($_GET['export_csv']) && $_GET['export_csv'] === '1') {
        cbp_export_csv();
        exit;
    }
    
    $payments = $wpdb->get_results("SELECT * FROM {$table_name} ORDER BY payment_date DESC");
    $total_payments = count($payments);
    $total_revenue = $wpdb->get_var("SELECT SUM(amount) FROM {$table_name}");
    $total_teams = $wpdb->get_var("SELECT SUM(num_teams) FROM {$table_name}");
    ?>
    <div class="wrap">
        <h1>College Bowl Payments</h1>
        <p><a href="?page=college-bowl-settings" class="button">⚙️ Settings</a></p>
        
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:20px;margin:20px 0">
            <div style="background:#fff;padding:20px;border-left:4px solid #0073aa">
                <h3>Total Payments</h3>
                <p style="font-size:32px;font-weight:bold"><?php echo $total_payments; ?></p>
            </div>
            <div style="background:#fff;padding:20px;border-left:4px solid #46b450">
                <h3>Total Revenue</h3>
                <p style="font-size:32px;font-weight:bold">$<?php echo number_format($total_revenue, 2); ?></p>
            </div>
            <div style="background:#fff;padding:20px;border-left:4px solid #dc3232">
                <h3>Total Teams</h3>
                <p style="font-size:32px;font-weight:bold"><?php echo $total_teams; ?></p>
            </div>
        </div>
        
        <div style="margin:20px 0">
            <a href="?page=college-bowl-payments&export_csv=1" class="button button-primary">Export to CSV</a>
        </div>
        
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Date</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>College</th>
                    <th>Teams</th>
                    <th>Amount</th>
                    <th>Transaction ID</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($payments)): ?>
                    <tr>
                        <td colspan="8" style="text-align:center;padding:40px">No payments received yet.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($payments as $p): ?>
                        <tr>
                            <td><?php echo $p->id; ?></td>
                            <td><?php echo date('M j, Y g:i A', strtotime($p->payment_date)); ?></td>
                            <td><?php echo esc_html($p->name); ?></td>
                            <td><a href="mailto:<?php echo esc_attr($p->email); ?>"><?php echo esc_html($p->email); ?></a></td>
                            <td><?php echo esc_html($p->college_name); ?></td>
                            <td><?php echo $p->num_teams == 0 ? '<strong style="color:#dc3232">TEST</strong>' : $p->num_teams; ?></td>
                            <td><strong>$<?php echo number_format($p->amount, 2); ?></strong></td>
                            <td><code><?php echo esc_html($p->stripe_payment_intent_id); ?></code></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php
}

// CSV Export function
function cbp_export_csv() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'college_bowl_payments';
    $payments = $wpdb->get_results("SELECT * FROM {$table_name} ORDER BY payment_date DESC", ARRAY_A);
    
    $filename = 'college-bowl-payments-' . date('Y-m-d') . '.csv';
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=' . $filename);
    
    $output = fopen('php://output', 'w');
    fputcsv($output, array('ID', 'Date', 'Name', 'Email', 'College', 'Teams', 'Amount', 'Transaction ID', 'IP'));
    
    foreach ($payments as $p) {
        fputcsv($output, array(
            $p['id'], 
            $p['payment_date'], 
            $p['name'], 
            $p['email'], 
            $p['college_name'], 
            $p['num_teams'] == 0 ? 'TEST' : $p['num_teams'], 
            $p['amount'], 
            $p['stripe_payment_intent_id'], 
            $p['ip_address']
        ));
    }
    
    fclose($output);
}
